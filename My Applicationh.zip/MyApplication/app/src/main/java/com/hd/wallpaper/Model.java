package com.hd.wallpaper;

public class Model {
    private String imageUrl;
    private String imagename;
    public Model() {

    }
    public Model(String imageUrl,String imagename) {
        this.imageUrl=imageUrl;
        this.imagename=imagename;
    }
    public String getImageUrl() {
        return imageUrl;
    }
    public void setImageUrl(String imageUrl) {
        this.imageUrl=imageUrl;
    }

    public String getImagename() {
        return imagename;
    }

    public void setImagename(String imagename) {
        this.imagename = imagename;
    }
}

package com.hd.wallpaper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CategoryimageActivity extends AppCompatActivity {
    RecyclerView catrecycle;
    CatAdapter myAdapter;


    ArrayList<Integer> threedlist;
    ArrayList<Integer> animlist;
    ArrayList<Integer> artlist;
    ArrayList<Integer> carlist;
    ArrayList<Integer> cartoonlist;
    ArrayList<Integer> citylist;
    ArrayList<Integer> colorlist;
    ArrayList<Integer> darklist;
    ArrayList<Integer> earthlist;
    ArrayList<Integer> flowerlist;
    ArrayList<Integer> fruitlist;
    ArrayList<Integer> hallolist;
    ArrayList<Integer> landlist;
    ArrayList<Integer> naturelist;
    ArrayList<Integer> ultralist;
    TextView txtheader;
    ImageView imgback;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categoryimage);
        String st = getIntent().getStringExtra("Catimg");
        Log.e("ssssss", "onCreate: " + st);

        txtheader=findViewById(R.id.txtheader);
        imgback=findViewById(R.id.imgback);
        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        txtheader.setText(st);
        threedlist=new ArrayList<>();
        animlist= new ArrayList<>();
        artlist=new ArrayList<>();
        carlist=new ArrayList<>();
        cartoonlist =new ArrayList<>();
        citylist=new ArrayList<>();
        colorlist=new ArrayList<>();
        darklist =new ArrayList<>();
        earthlist=new ArrayList<>();
        flowerlist=new ArrayList<>();
        fruitlist= new ArrayList<>();
        hallolist=new ArrayList<>();
        landlist=new ArrayList<>();
        naturelist =new ArrayList<>();
        ultralist=new ArrayList<>();

        fruitlist.add(R.drawable.fr1);
        fruitlist.add(R.drawable.fr2);
        fruitlist.add(R.drawable.fr3);
        fruitlist.add(R.drawable.fr4);
        fruitlist.add(R.drawable.fr5);
        fruitlist.add(R.drawable.fr6);
        fruitlist.add(R.drawable.fr7);
        fruitlist.add(R.drawable.fr8);
        fruitlist.add(R.drawable.fr9);
        fruitlist.add(R.drawable.fr10);


        threedlist.add(R.drawable.td1);
        threedlist.add(R.drawable.td2);
        threedlist.add(R.drawable.td3);
        threedlist.add(R.drawable.td4);
        threedlist.add(R.drawable.td5);
        threedlist.add(R.drawable.td6);
        threedlist.add(R.drawable.td7);
        threedlist.add(R.drawable.td8);
        threedlist.add(R.drawable.td9);
        threedlist.add(R.drawable.td10);

        animlist.add(R.drawable.anm1);
        animlist.add(R.drawable.anm2);
        animlist.add(R.drawable.anm3);
        animlist.add(R.drawable.anm4);
        animlist.add(R.drawable.anm5);
        animlist.add(R.drawable.anm6);
        animlist.add(R.drawable.anm7);
        animlist.add(R.drawable.anm8);
        animlist.add(R.drawable.anm9);
        animlist.add(R.drawable.anm10);

        artlist.add(R.drawable.ar1);
        artlist.add(R.drawable.ar2);
        artlist.add(R.drawable.ar3);
        artlist.add(R.drawable.ar4);
        artlist.add(R.drawable.ar5);
        artlist.add(R.drawable.ar6);
        artlist.add(R.drawable.ar7);
        artlist.add(R.drawable.ar8);
        artlist.add(R.drawable.ar9);
        artlist.add(R.drawable.ar10);

        carlist.add(R.drawable.cr1);
        carlist.add(R.drawable.cr2);
        carlist.add(R.drawable.cr3);
        carlist.add(R.drawable.cr4);
        carlist.add(R.drawable.cr5);
        carlist.add(R.drawable.cr6);
        carlist.add(R.drawable.cr7);
        carlist.add(R.drawable.cr8);
        carlist.add(R.drawable.cr9);
        carlist.add(R.drawable.cr10);

        cartoonlist.add(R.drawable.ct1);
        cartoonlist.add(R.drawable.ct2);
        cartoonlist.add(R.drawable.ct3);
        cartoonlist.add(R.drawable.ct4);
        cartoonlist.add(R.drawable.ct5);
        cartoonlist.add(R.drawable.ct6);
        cartoonlist.add(R.drawable.ct7);
        cartoonlist.add(R.drawable.ct8);
        cartoonlist.add(R.drawable.ct9);
        cartoonlist.add(R.drawable.ct10);

        citylist.add(R.drawable.cy1);
        citylist.add(R.drawable.cy2);
        citylist.add(R.drawable.cy3);
        citylist.add(R.drawable.cy4);
        citylist.add(R.drawable.cy5);
        citylist.add(R.drawable.cy6);
        citylist.add(R.drawable.cy7);
        citylist.add(R.drawable.cy8);
        citylist.add(R.drawable.cy9);
        citylist.add(R.drawable.cy10);

        colorlist.add(R.drawable.cl1);
        colorlist.add(R.drawable.cl2);
        colorlist.add(R.drawable.cl3);
        colorlist.add(R.drawable.cl4);
        colorlist.add(R.drawable.cl5);
        colorlist.add(R.drawable.cl6);
        colorlist.add(R.drawable.cl7);
        colorlist.add(R.drawable.cl8);
        colorlist.add(R.drawable.cl9);
        colorlist.add(R.drawable.cl10);

        darklist.add(R.drawable.dr1);
        darklist.add(R.drawable.dr2);
        darklist.add(R.drawable.dr3);
        darklist.add(R.drawable.dr4);
        darklist.add(R.drawable.dr5);
        darklist.add(R.drawable.dr6);
        darklist.add(R.drawable.dr7);
        darklist.add(R.drawable.dr8);
        darklist.add(R.drawable.dr9);
        darklist.add(R.drawable.dr10);

        earthlist.add(R.drawable.er1);
        earthlist.add(R.drawable.er2);
        earthlist.add(R.drawable.er3);
        earthlist.add(R.drawable.er4);
        earthlist.add(R.drawable.er5);
        earthlist.add(R.drawable.er6);
        earthlist.add(R.drawable.er7);
        earthlist.add(R.drawable.er8);
        earthlist.add(R.drawable.er9);
        earthlist.add(R.drawable.er10);

        flowerlist.add(R.drawable.fl1);
        flowerlist.add(R.drawable.fl2);
        flowerlist.add(R.drawable.fl3);
        flowerlist.add(R.drawable.fl4);
        flowerlist.add(R.drawable.fl5);
        flowerlist.add(R.drawable.fl6);
        flowerlist.add(R.drawable.fl7);
        flowerlist.add(R.drawable.fl8);
        flowerlist.add(R.drawable.fl9);
        flowerlist.add(R.drawable.fl10);


        hallolist.add(R.drawable.hw1);
        hallolist.add(R.drawable.hw2);
        hallolist.add(R.drawable.hw3);
        hallolist.add(R.drawable.hw4);
        hallolist.add(R.drawable.hw5);
        hallolist.add(R.drawable.hw6);
        hallolist.add(R.drawable.hw7);
        hallolist.add(R.drawable.hw8);
        hallolist.add(R.drawable.hw9);
        hallolist.add(R.drawable.hw10);

        landlist.add(R.drawable.ld1);
        landlist.add(R.drawable.ld2);
        landlist.add(R.drawable.ld3);
        landlist.add(R.drawable.ld4);
        landlist.add(R.drawable.ld5);
        landlist.add(R.drawable.ld6);
        landlist.add(R.drawable.ld7);
        landlist.add(R.drawable.ld8);
        landlist.add(R.drawable.ld9);
        landlist.add(R.drawable.ld10);

        naturelist.add(R.drawable.nr1);
        naturelist.add(R.drawable.nr2);
        naturelist.add(R.drawable.nr3);
        naturelist.add(R.drawable.nr4);
        naturelist.add(R.drawable.nr5);
        naturelist.add(R.drawable.nr6);
        naturelist.add(R.drawable.nr7);
        naturelist.add(R.drawable.nr8);
        naturelist.add(R.drawable.nr9);
        naturelist.add(R.drawable.nr10);

        ultralist.add(R.drawable.us1);
        ultralist.add(R.drawable.us2);
        ultralist.add(R.drawable.us3);
        ultralist.add(R.drawable.us4);
        ultralist.add(R.drawable.us5);
        ultralist.add(R.drawable.us6);
        ultralist.add(R.drawable.us7);
        ultralist.add(R.drawable.us8);
        ultralist.add(R.drawable.us9);
        ultralist.add(R.drawable.us10);


        catrecycle = findViewById(R.id.catrecycle);
        catrecycle.setHasFixedSize(true);
        catrecycle.setLayoutManager(new GridLayoutManager(this,3)); //gallerybtn

        if (st.equals("3D")) {
            myAdapter = new CatAdapter(threedlist, CategoryimageActivity.this);
        }
        else if (st.equals("animation")){
            myAdapter = new CatAdapter(animlist, CategoryimageActivity.this);
        }
        else if (st.equals("art")) {
            myAdapter = new CatAdapter(artlist, CategoryimageActivity.this);
        }
        else if (st.equals("car")) {
            myAdapter = new CatAdapter(carlist, CategoryimageActivity.this);
        }
        else if (st.equals("cartoons")) {
            myAdapter = new CatAdapter(cartoonlist, CategoryimageActivity.this);
        }
        else if (st.equals("city")) {
            myAdapter = new CatAdapter(citylist, CategoryimageActivity.this);
        }
        else if (st.equals("colors")) {
            myAdapter = new CatAdapter(colorlist, CategoryimageActivity.this);
        }
        else if (st.equals("dark")) {
            myAdapter = new CatAdapter(darklist, CategoryimageActivity.this);
        }
        else if (st.equals("earth")) {
            myAdapter = new CatAdapter(earthlist, CategoryimageActivity.this);
        }
        else if (st.equals("flowers")) {
            myAdapter = new CatAdapter(flowerlist, CategoryimageActivity.this);
        }
        else if (st.equals("fruits")) {
            myAdapter = new CatAdapter(fruitlist, CategoryimageActivity.this);
        }
        else if (st.equals("halloween")) {
            myAdapter = new CatAdapter(hallolist, CategoryimageActivity.this);
        }
        else if (st.equals("landscapes")) {
            myAdapter = new CatAdapter(landlist, CategoryimageActivity.this);
        }
        else if (st.equals("nature")) {
            myAdapter = new CatAdapter(naturelist, CategoryimageActivity.this);
        }
        else/* if (st.equals("ultrastack")) */{
            myAdapter = new CatAdapter(ultralist, CategoryimageActivity.this);
        }

            catrecycle.setAdapter(myAdapter);
        myAdapter.notifyDataSetChanged();


    }
}
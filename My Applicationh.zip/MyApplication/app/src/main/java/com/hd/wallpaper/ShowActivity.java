package com.hd.wallpaper;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.hd.wallpaper.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ShowActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    private MyAdapter myAdapter;
    private MyAdapter myAdapterfr;
    private MyAdapter myAdapterfl;
    private MyAdapter myAdapterct;
    private MyAdapter myAdapteranm;
    private MyAdapter myAdaptercl;
    private MyAdapter myAdapterld;
    private MyAdapter myAdapterer;
    private MyAdapter myAdapter3d;
    private MyAdapter myAdapterar;
    private MyAdapter myAdapterdr;
    private MyAdapter myAdaptercy;
    private MyAdapter myAdaptercr;
    private MyAdapter myAdapterhw;
    private MyAdapter myAdapterus;

    private ArrayList<Model> listnature;
    private ArrayList<Model> listfruits;
    private ArrayList<Model> listflowers;
    private ArrayList<Model> listcartoons;
    private ArrayList<Model> listanimated;
    private ArrayList<Model> listcolor;
    private ArrayList<Model> listlandscape;
    private ArrayList<Model> listearth;
    private ArrayList<Model> list3d;
    private ArrayList<Model> listart;
    private ArrayList<Model> listdark;
    private ArrayList<Model> listcity;
    private ArrayList<Model> listcar;
    private ArrayList<Model> listhalloween;
    private ArrayList<Model> listultrastack;


    private DatabaseReference root = FirebaseDatabase.getInstance().getReference("Image");
    public Button btnflower, btnnature, btnFruit,btnCartoon,btnAnimated,btnColor,btnLandscape,btnEarth,btn3D,btnArt,btnDark,btnCity,btnCar,btnHalloween,btnUltrastack;
    TextView noimg;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);


        noimg=findViewById(R.id.noimg);
        btnflower=findViewById(R.id.btnflower);
        btnnature=findViewById(R.id.btnnature);
        btnFruit=findViewById(R.id.btnFruit);
        btnCartoon=findViewById(R.id.btnCartoon);
        btnAnimated=findViewById(R.id.btnAnimated);
        btnColor=findViewById(R.id.btnColor);
        btnLandscape=findViewById(R.id.btnLandscape);
        btnEarth=findViewById(R.id.btnEarth);
        btn3D=findViewById(R.id.btn3D);
        btnArt=findViewById(R.id.btnArt);
        btnDark=findViewById(R.id.btnDark);
        btnCity=findViewById(R.id.btnCity);
        btnCar=findViewById(R.id.btnCar);
        btnHalloween=findViewById(R.id.btnHalloween);
        btnUltrastack=findViewById(R.id.btnUltrastack);

        recyclerView = findViewById(R.id.recycle);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listnature=new ArrayList<>();
        listfruits=new ArrayList<>();
        listflowers=new ArrayList<>();
        listcartoons=new ArrayList<>();
        listanimated=new ArrayList<>();
        listcolor=new ArrayList<>();
        listlandscape=new ArrayList<>();
        listearth=new ArrayList<>();
        list3d=new ArrayList<>();
        listart=new ArrayList<>();
        listdark=new ArrayList<>();
        listcity=new ArrayList<>();
        listcar=new ArrayList<>();
        listhalloween=new ArrayList<>();
        listultrastack=new ArrayList<>();

        myAdapter=new MyAdapter(listnature, ShowActivity.this);
        myAdapterfr=new MyAdapter(listfruits, ShowActivity.this);
        myAdapterfl=new MyAdapter(listflowers, ShowActivity.this);
        myAdapterct=new MyAdapter(listcartoons,ShowActivity.this);
        myAdapteranm=new MyAdapter(listanimated,ShowActivity.this);
        myAdaptercl=new MyAdapter(listcolor,ShowActivity.this);
        myAdapterld=new MyAdapter(listlandscape,ShowActivity.this);
        myAdapterer=new MyAdapter(listearth,ShowActivity.this);
        myAdapter3d=new MyAdapter(list3d,ShowActivity.this);
        myAdapterar=new MyAdapter(listart,ShowActivity.this);
        myAdapterdr=new MyAdapter(listdark,ShowActivity.this);
        myAdaptercy=new MyAdapter(listcity,ShowActivity.this);
        myAdaptercr=new MyAdapter(listcar,ShowActivity.this);
        myAdapterhw=new MyAdapter(listhalloween,ShowActivity.this);
        myAdapterus=new MyAdapter(listultrastack,ShowActivity.this);


        if (!listnature.isEmpty()) {
            listnature.clear();
        }
        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Model model = dataSnapshot.getValue(Model.class);
                    String s = model.getImagename();
                    if (s.equals("Nature")) {
                        noimg.setVisibility(View.GONE);
                        listnature.add(model);
                    }   if (listnature.isEmpty()) {
                        noimg.setVisibility(View.VISIBLE);
                    }
                }
                recyclerView.setAdapter(myAdapter);
                myAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btnflower.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listflowers.isEmpty()) {
                    listflowers.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();

                            if (s.equals("Flowers")) {
                                Log.e("Flowers", "onDataChange: " );
                                noimg.setVisibility(View.GONE);
                                listflowers.add(model);
                            }
                            if (listflowers.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterfl);
                        myAdapterfl.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

        btnnature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listnature.isEmpty()) {
                    listnature.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                             if (s.equals("Nature")) {
                                noimg.setVisibility(View.GONE);
                                listnature.add(model);
                            } if (listnature.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapter);
                        myAdapter.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnFruit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listfruits.isEmpty()) {
                    listfruits.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                             if (s.equals("Fruits")) {
                                noimg.setVisibility(View.GONE);
                                listfruits.add(model);
                            }
                            if (listfruits.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterfr);
                        myAdapterfr.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

        btnCartoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listcartoons.isEmpty()) {
                    listcartoons.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Cartoons")) {
                                noimg.setVisibility(View.GONE);
                                listcartoons.add(model);
                            }
                            if (listcartoons.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterct);
                        myAdapterfr.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnAnimated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listanimated.isEmpty()) {
                    listanimated.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Animation")) {
                                noimg.setVisibility(View.GONE);
                                listanimated.add(model);
                            }
                            if (listanimated.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapteranm);
                        myAdapteranm.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listcolor.isEmpty()) {
                    listcolor.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Colour")) {
                                noimg.setVisibility(View.GONE);
                                listcolor.add(model);
                            }
                            if (listcolor.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdaptercl);
                        myAdaptercl.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnLandscape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listlandscape.isEmpty()) {
                    listlandscape.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Landscapes")) {
                                noimg.setVisibility(View.GONE);
                                listlandscape.add(model);
                            }
                            if (listlandscape.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterld);
                        myAdapterld.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnEarth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listearth.isEmpty()) {
                    listearth.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Earth")) {
                                noimg.setVisibility(View.GONE);
                                listearth.add(model);
                            }
                            if (listearth.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterer);
                        myAdapterer.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btn3D.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!list3d.isEmpty()) {
                    list3d.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("3D")) {
                                noimg.setVisibility(View.GONE);
                                list3d.add(model);
                            }
                            if (list3d.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapter3d);
                        myAdapter3d.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnArt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listart.isEmpty()) {
                    listart.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Art")) {
                                noimg.setVisibility(View.GONE);
                                listart.add(model);
                            }
                            if (listart.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterar);
                        myAdapterar.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnDark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listdark.isEmpty()) {
                    listdark.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Dark")) {
                                noimg.setVisibility(View.GONE);
                                listdark.add(model);
                            }
                            if (listdark.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterdr);
                        myAdapterdr.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listcity.isEmpty()) {
                    listcity.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("City")) {
                                noimg.setVisibility(View.GONE);
                                listcity.add(model);
                            }
                            if (listcity.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdaptercy);
                        myAdaptercy.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listcar.isEmpty()) {
                    listcar.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Car")) {
                                noimg.setVisibility(View.GONE);
                                listcar.add(model);
                            }
                            if (listcar.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdaptercr);
                        myAdaptercr.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnHalloween.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listhalloween.isEmpty()) {
                    listhalloween.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Halloween")) {
                                noimg.setVisibility(View.GONE);
                                listhalloween.add(model);
                            }
                            if (listhalloween.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterhw);
                        myAdapterhw.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        btnUltrastack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!listultrastack.isEmpty()) {
                    listultrastack.clear();
                }
                root.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            Model model = dataSnapshot.getValue(Model.class);
                            String s = model.getImagename();
                            if (s.equals("Ultrastack")) {
                                noimg.setVisibility(View.GONE);
                                listultrastack.add(model);
                            }
                            if (listultrastack.isEmpty()) {
                                noimg.setVisibility(View.VISIBLE);
                            }
                        }
                        recyclerView.setAdapter(myAdapterus);
                        myAdapterus.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });





/*
        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Model model = dataSnapshot.getValue(Model.class);
                    String s = model.getImagename();
                    if (s.equals("Nature")) {
                        listnature.add(model);
                    } else if (s.equals("Fruits")) {
                        listfruits.add(model);
                    } else if (s.equals("Flowers")) {
                        listflowers.add(model);
                    }
                    Log.e("aasasas", "onDataChange: " + listnature.size());
                }

                recyclerView.setAdapter(myAdapter);
                myAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
*/
    }
}
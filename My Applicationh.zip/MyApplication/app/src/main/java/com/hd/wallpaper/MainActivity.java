package com.hd.wallpaper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.hd.wallpaper.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ImageView upload, show, imageView1;
    public int PICK_IMAGE_REQUEST=11;
    public Uri filepath;
    Bitmap bitmap;
    EditText editText;
    Spinner sp;

 String   temptxt;
    private DatabaseReference rootnature= FirebaseDatabase.getInstance().getReference("Image");
     private StorageReference reference=FirebaseStorage.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        upload=findViewById(R.id.btnupload);
        imageView1=findViewById(R.id.image2);
        show=findViewById(R.id.btndisplay);
        sp=findViewById(R.id.spinner);
        List<String> list=new ArrayList<String>();
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,list);
        list.add("Animation");
        list.add("Art");
        list.add("Car");
        list.add("Cartoon");
        list.add("City");
        list.add("Colour");
        list.add("Dark");
        list.add("Earth");
        list.add("Flower");
        list.add("Fruit");
        list.add("Halloween");
        list.add("Landscape");
        list.add("Nature");
        list.add("Ultrastack");
        list.add("3D");
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(adapter);


       sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
temptxt= (String) parent.getSelectedItem();

           }

           @Override
           public void onNothingSelected(AdapterView<?> parent) {

           }
       });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(filepath!=null)
                { uploadToFirebase(filepath);}
                else {Toast.makeText(MainActivity.this, "please select image", Toast.LENGTH_SHORT).show();}
            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ShowActivity.class);
                startActivity(intent);
            }
        });

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent.createChooser(intent,"Select Picture"),PICK_IMAGE_REQUEST);

            }
        });

        findViewById(R.id.button11).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,MainActivity2.class);
                startActivity(intent);
            }
        });
    }

    private void uploadToFirebase(Uri filepath) {

        final StorageReference fileRef = reference.child(System.currentTimeMillis() + "." + getFileExtension(filepath));
        fileRef.putFile(filepath).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
//                       String temptxt=editText.getText().toString();
                        Model model = new Model(uri.toString(),temptxt);
//                        if (temptxt.equals("Fruits")){
//                            String modelId = rootfruit.push().getKey();
//                            rootfruit.child(modelId).setValue(model);
//
//                        }
//                        else if (temptxt.equals("Nature")){
                            String modelId = rootnature.push().getKey();
                            rootnature.child(modelId).setValue(model);

//                        }
//                        else if (temptxt.equals("Flowers")){
//                            String modelId = rootflowers.push().getKey();
//                            rootflowers.child(modelId).setValue(model);
//
//                        }
                        Toast.makeText(MainActivity.this, "Uploaded Successfully", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, "Uploading Failed !!", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private String getFileExtension(Uri mUri){

        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==PICK_IMAGE_REQUEST&& resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            filepath=data.getData();
            try
            {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filepath);
                imageView1.setImageBitmap(bitmap);
            } catch (IOException e)
            {
                e.printStackTrace();
            }

        }
    }
}
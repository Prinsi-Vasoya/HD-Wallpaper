package com.hd.wallpaper;

import static java.security.AccessController.getContext;

import android.app.Activity;
import android.app.Dialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CatAdapter extends RecyclerView.Adapter<CatAdapter.MyViewHolder> {
    private List<Integer> mlist;
    ArrayList<Bitmap> list ;
    private Context context;


    public CatAdapter(List<Integer> mlist, Context context) {
        this.mlist = mlist;
        this.context = context;
    }

    @NonNull
    @Override
    public CatAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.catitem, parent, false);
        return new CatAdapter.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CatAdapter.MyViewHolder holder, int position) {
        Glide.with(context).load(mlist.get(position)).into(holder.imageView);
        Dialog dialog = new Dialog(context);

        holder.itemView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                dialog.setContentView(R.layout.dialog_layout);
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                dialog.setCancelable(true);
                //  dialog.getWindow().getAttributes().windowAnimations = R.style.animation;

                View txtboth = dialog.findViewById(R.id.txtboth);
                View txtlockscreen = dialog.findViewById(R.id.txtlockscreen);
                View txtdesktop = dialog.findViewById(R.id.txtdesktop);
                View imgclose = dialog.findViewById(R.id.imgclose);
                imgclose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });

                txtboth.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        try {
                            Toast.makeText(context, "Wallpaper Set Success", Toast.LENGTH_SHORT).show();


                            WallpaperManager wallpaperManager = WallpaperManager.getInstance(context);
                            Drawable drawable = holder.imageView.getDrawable();
                            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
                            int width = getScreenWidth();
                            int height = getScreenHeight();
                            Bitmap bitmapToUse = Bitmap.createScaledBitmap(bitmap, width, height, true);
                            wallpaperManager.setBitmap(bitmapToUse);
                            dialog.dismiss();


                        } catch (IOException e) {
                            Toast.makeText(context, "catch", Toast.LENGTH_SHORT).show();
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }

                    }
                });

                txtlockscreen.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            Toast.makeText(context, "Wallpaper Set Success", Toast.LENGTH_SHORT).show();


                            WallpaperManager wallpaperManager = WallpaperManager.getInstance(context);

                            Drawable drawable = holder.imageView.getDrawable();
                            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
                            int width = getScreenWidth();
                            int height = getScreenHeight();
                            Bitmap bitmapToUse = Bitmap.createScaledBitmap(bitmap, width, height, true);
                            wallpaperManager.setBitmap(bitmapToUse,null,true,WallpaperManager.FLAG_LOCK);
                            dialog.dismiss();


                        } catch (IOException e) {
                            Toast.makeText(context, "catch", Toast.LENGTH_SHORT).show();
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                });

                txtdesktop.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            Toast.makeText(context, "Wallpaper Set Success", Toast.LENGTH_SHORT).show();


                            WallpaperManager wallpaperManager = WallpaperManager.getInstance(context);
                            Drawable drawable = holder.imageView.getDrawable();
                            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
                            DisplayMetrics metrics=new DisplayMetrics();
                            int width = getScreenWidth();
                            int height = getScreenHeight();
                            Bitmap bitmapToUse = Bitmap.createScaledBitmap(bitmap, width, height, true);
                            wallpaperManager.setBitmap(bitmapToUse,null,true,WallpaperManager.FLAG_SYSTEM);
                            dialog.dismiss();


                        } catch (IOException e) {
                            Toast.makeText(context, "catch", Toast.LENGTH_SHORT).show();
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                });

                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
//
            }
        });


    }
    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static int getScreenHeight() {
        return Resources.getSystem().getDisplayMetrics().heightPixels;
    }
    @Override
    public int getItemCount() {
        return mlist.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }

}

package com.hd.wallpaper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity2 extends AppCompatActivity {

    RecyclerView recyclerView;
    private MyAdapter1 myAdapter;
    private ArrayList<String> listnature;

    public ArrayList<String> listImages;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        recyclerView=findViewById(R.id.recycle);
//
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); //2grid
//        listnature=new ArrayList<>();
//
//        listnature.add(listImages);
//
        myAdapter=new MyAdapter1( MainActivity2.this);
//
        recyclerView.setAdapter(myAdapter);
        myAdapter.notifyDataSetChanged();


    }
}